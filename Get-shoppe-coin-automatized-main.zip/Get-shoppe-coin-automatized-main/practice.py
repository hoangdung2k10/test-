import os
token = os.environ["LINE_NOTIFY_TOKEN"]
print(token)
